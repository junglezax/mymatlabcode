%% 测试 feature scaling 对 theta 的影响

clear ; close all; clc
maxv = 10;
%x = double(int32(rand(3, 3)*maxv));
%det(x'*x) % 似乎行列数相差越大，这个值越小；10以内的数，行列数小于6时，也很小; 当行列数相等时，值突然变很大；不相等，9x10时才出现个位数

m = 3;
n = 2;
%data = double(int32(rand(m, n+1)*maxv))
%testx = double(int32(rand(1, n)*maxv))
data = [
     9     3     8
     7     8     9
     1     7     2
]
testx = [9, 3]
%n = size(data, 2)-1;
X = data(:, 1:n);
Xorg = X;
y = data(:, n+1);
%m = length(y);

scl = false;
if scl
	fprintf('Normalizing Features ...\n'); [X mu sigma] = featureNormalize(X);
end

% Add intercept term to X
X = [ones(m, 1) X];

fprintf('Running gradient descent ...\n');

% Choose some alpha value
alpha = 1e-4; % alpha 太小时，如果设定的收敛阈值比较大，那么得到的精度可能还不如较大的权值（比如eps=0.01，alpha=1e-5远远没有1e-2精确

% Init Theta and Run Gradient Descent 
theta = zeros(n+1, 1);
[theta, J_history, num_iters] = gradientDescentMulti(X, y, theta, alpha, 0);
disp(num_iters)

% Plot the convergence graph
%figure;
%plot(1:num_iters, J_history(1:num_iters), '-b', 'LineWidth', 2);
%xlabel('Number of iterations');
%ylabel('Cost J');

if scl
	price1 = [1 featureNormalize(testx)] * theta;
else
	price1 = [1 testx] * theta;
end
%t = bsxfun(@minus, X, mu);
%X_norm = bsxfun(@rdivide, t, sigma);
%price = price1 * sigma + mu;

%% ================ Part 3: Normal Equations ================

fprintf('Solving with normal equations...\n');

% Add intercept term to X
X = Xorg;
X = [ones(m, 1) X];

% Calculate the parameters from the normal equation
theta1 = normalEqn(X, y);

% 结果表明，带特征缩放时，GD和NE算得的theta不一样
% 测试表明，不进行特征缩放，两种方法求得的theta也不一样；算出的函数值当然也不一样
disp([theta theta1]')
disp((theta == theta1)')

price2 = [1 testx] * theta1;

% 结果表明，梯度下降得到的结果是错的
% NE 得到的结果是准确的
disp([price1; price2])
disp(price1 == price2)
